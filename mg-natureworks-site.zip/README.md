# M&G NatureWorks International Research Institute: website

A static, no-build website. Plain HTML, CSS and JavaScript. GSAP and Google Fonts load from CDNs.

## Run it locally
Open `index.html` in a browser, or serve the folder:

    python3 -m http.server 8000      # then visit http://localhost:8000

## Deploy on GitHub Pages
1. Create a repository and upload everything in this folder (keep the folder structure).
2. Repo Settings, Pages, Source: "Deploy from a branch", branch `main`, folder `/ (root)`.
3. Your site appears at `https://<username>.github.io/<repo>/`.

## Structure
    index.html            page markup
    css/styles.css        all styles
    js/frames.js          lists of video-frame image paths (FR = intro, FP = products)
    js/main.js            nav, hero scroll animation, showcase, globe, contact form, FAQ
    js/gallery.js         3D rotating product gallery, grid view, lightbox
    js/cards.js           3D Green Diamond product-card carousel
    js/pill.js            pill-reveal section above the footer
    assets/images/        logo, founders, outreach, product and range photos
    assets/frames/        frames extracted from the two supplied videos
    source-videos/        the original videos (not used by the page; keep for re-exporting frames)

## Things you will want to edit
- **Testimonials:** `TESTIMONIALS` array and the demo profiles near the globe code in `js/main.js`. The demo profiles are fictional and labelled; replace them with real, consented testimonials before launch.
- **Products:** product names and captions are in `js/gallery.js` (array `G`) and `js/cards.js` (array `C`).
- **Contact details:** phone, address and WhatsApp link are in `index.html` and `js/main.js`.
- **Contact form:** it has no backend. It validates and opens WhatsApp with the message prefilled.

## Regenerate the video frames (better quality)
    ffmpeg -i source-videos/intro.mp4 -vf "select='not(mod(n,2))',scale=1280:-2" -vsync vfr -q:v 4 assets/frames/intro/intro-%03d.jpg
    ffmpeg -i source-videos/products-on-pedestals.mp4 -vf "select='not(mod(n,4))',scale=1280:-2" -vsync vfr -q:v 4 assets/frames/products/products-%03d.jpg
Keep the frame counts (72 intro, 60 products) or update the lists in `js/frames.js`.

## Content to review before going public
- Health claims: product names such as "Sickle Cell Corrector" and "Thyroid Gland Activator" may count as treatment claims. Get regulatory and legal review.
- Founder portraits and product images look computer-generated; use real photographs where possible.
- Historical dates in the timeline (1986, 17 May 2010) need verification.
